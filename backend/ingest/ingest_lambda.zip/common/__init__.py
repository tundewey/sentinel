"""Shared Sentinel backend components."""
